====================================================================
  CRIMSON -- COMPLETE LOOT BEAM SET for ROSE Online
  red
====================================================================

WHAT THIS IS
Every drop group I have made, in one download.

  Chemicals & potions            Crimson
  Zodiac & Rune Stone            Crimson
  Dirty Crystal                  Crimson
  Dirty Ore & Dirty Stone        Crimson
  Spiritual & Heart Stone        Crimson
  Clan points                    Crimson
  Scrolls & event drops          Crimson
  Mounts                         Crimson
  Boss gems                      Crimson
  Effigies                       Crimson
  Rings, necklaces & earrings    Crimson
  Talismans, lisents, scarabs & powders Crimson

Each drop gets a new model and a tall beam of light above it, so you can
see what is worth walking over to without squinting at the ground.

If you would rather mix -- teal crystals but red ore, say -- download the
individual packs instead. They are on the same page. This bundle is
exactly those packs' files in one archive; nothing differs.

--------------------------------------------------------------------
HOW TO INSTALL
--------------------------------------------------------------------
1. Close ROSE completely.
2. Copy the '3ddata' folder from this pack into your ROSE Online
   install folder, letting it merge.
      Typical location: C:\Program Files\ROSE Online
3. Start the game.

Installing another color over the top replaces it. Installing a single
category pack over the top changes just that one drop group.

--------------------------------------------------------------------
HOW TO UNINSTALL
--------------------------------------------------------------------
Delete the files listed in FILE_LIST.txt. That's the whole process.

ROSE loads loose files on disk in preference to its packed archives, so
this does not modify or replace any original game data -- it sits on top
of it, and removing it falls straight back to stock.

--------------------------------------------------------------------
NOTES
--------------------------------------------------------------------
* Some filenames do not match their folder -- di22 uses 'd22.zms', di55
  uses 'snow.zms' and 'rock.dds', accessories use 'necklace01.dds' for
  the ring as well. That is what the game asks for. Don't rename them.
* Boss gems ship four identical textures because four gem types share
  one model and each reads its own folder.
* All artwork here is original work. No third-party assets are included
  and no game files are redistributed.
* Nothing in this archive can execute.
