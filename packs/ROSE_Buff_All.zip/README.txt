====================================================================
  REGAL BUFFS -- all nine effects
  effects only, no icons
====================================================================

Nine buff auras, redrawn. Each has a distinct silhouette rather than
just a distinct colour, so you can tell at a glance which is running.

    Power Overflow      attack power up      Soldier
    Haste               attack speed up      Hawker
    Critical Chant      critical rate up     Dealer
    Dealer's Influence  accuracy up          Dealer
    Enhanced Reflexes   dodge up             Hawker
    Valkyrie Charm      damage up            Muse
    Rapid Twitch        move speed up        Hawker
    Resistance Chant    magic defence up     Muse
    Durability Assist   defence up           Soldier

Each is also available on its own if you only want one.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete the files listed in FILE_LIST.txt. That is the complete set
and nothing else is touched.

--------------------------------------------------------------------
THE ICONS ARE A SEPARATE PACK
--------------------------------------------------------------------
The sixteen buff icons are all one shared sheet --
3ddata\control\Res\stateicon.dds -- rather than separate images.
That same sheet also carries quest log icons and minimap markers, so
two icon packs can never be combined: whichever is installed last
wins the whole thing.

--------------------------------------------------------------------
WORTH KNOWING
--------------------------------------------------------------------
The game's own filenames do not match the buffs they draw. Attack
speed is defendup_01.ptl. Magic defence is _horsepower_02.ptl. If
you are modding these yourself, search for what an effect draws
rather than what it is called.

Defence up is drawn by an effect mesh rather than a particle file,
so it is textures only.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files in FILE_LIST.txt and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
