====================================================================
  REGAL BUFFS -- Resistance Chant
  magic defence up  --  Muse
====================================================================

Five rune spirals climbing around the body.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 6 file(s):

    3ddata\EFFECT\Particles\_horsepower_02.ptl
    3ddata\EFFECT\Particles\Texture\rune0.dds
    3ddata\EFFECT\Particles\Texture\rune1.dds
    3ddata\EFFECT\Particles\Texture\rune2.dds
    3ddata\EFFECT\Particles\Texture\rune3.dds
    3ddata\EFFECT\Particles\Texture\rune4.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
WORTH KNOWING
--------------------------------------------------------------------
The file it replaces is called _horsepower_02.ptl. That is not a
mistake -- the Korean word for magical power also means horsepower,
and the translation picked the wrong one.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
