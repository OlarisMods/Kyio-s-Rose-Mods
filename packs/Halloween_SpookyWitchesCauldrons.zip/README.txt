====================================================================
  VOID HALLOWEEN -- CAULDRON BEAMS
====================================================================

WHAT THIS IS
A bubbling cauldron on every drop group, with the brew colour telling
you which group it is. The pot, the spoon and the iron stay the same
everywhere; only the brew, the bubbles and the thin band round the
waist change colour.

    marsh green   chemicals
    violet        zodiac stones, rune stones, mounts
    spirit teal   dirty crystal, spiritual and heart stones
    amber         effigies, rings, necklaces, dirty ore and stone
    blood red     clan points, boss gems
    glow          scrolls, event drops and some jewels

The bubbles are the beam. They rise the full height a loot beam
occupies, spreading and shrinking as they go.

The pot is the click target and it is deliberately wide -- the
standing complaint about loot beams is that they are hard to click.

--------------------------------------------------------------------
HOW TO INSTALL
--------------------------------------------------------------------
1. Close ROSE completely.
2. Copy the '3ddata' folder into your ROSE Online install folder,
   letting it merge.   Typical: C:\Program Files\ROSE Online
3. Start the game.

Uses the same filenames as the other beam packs, so installing one
over another swaps them cleanly.

--------------------------------------------------------------------
HOW TO UNINSTALL
--------------------------------------------------------------------
UNINSTALL
    Every file this pack installs is listed in .packilelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.


UNINSTALL
    Every file this pack installs is listed in .pack\filelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
