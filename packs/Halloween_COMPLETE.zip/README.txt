UPDATED FOR THE 16 OCTOBER 2026 PATCH  (version 1.1.0)
=====================================================
Rebuilt on the patched interface: the new chat settings button, party and
group controls, the HUD status icons and the data-driven minimap all work,
and every Spooky colour and addition is kept.

The headstone's sprites moved to spritesheet_spooky.css. The HP, MP, EXP
and fuel bars carry their colour in the texture now -- the patch stopped
tinting bar fills from the stylesheet.

UPGRADING FROM 1.0  -- one file to delete
    Delete this file from your ROSE Online folder if it is there:

        data\ui\themes\rose\styles\spritesheet_glassui.css

    Version 1.0 shipped its own copy of that sheet. A copy in your folder
    overrides the game's, so the patch's new buttons would draw blank.
    Spooky's sprites now live in their own file, spritesheet_spooky.css,
    and the game's sheet is left alone.

-----------------------------------------------------

VOID HALLOWEEN -- THE COMPLETE BUNDLE
====================================

Everything finished for Halloween, in one install, layered in order onto
the Spooky UI so every file that should win does.

    00  Spooky UI            the base theme
    01  Buffs                nine effects, the dodge ghost included
    02  Combat Text          digits, status words, the crit bat flock
    03  Cauldron Beams       all fourteen drop groups
    04  Haunted Summons      the aurora and the wisps
    05  State Icons          a colour for every class
    06  Summon Gauge         the reworked summon bar
    07  Tombstone Minimap    a headstone round the map

Five pack files deliberately replace Spooky UI files -- the minimap's
frame, sprite sheet and document, and the state icon sheet in both of its
folders. Each was built FROM your Spooky UI file and extends it.

INSTALL
    Onto a CLEAN client: remove every earlier test file first (see
    TEST_FILES_TO_DELETE.txt). Then copy the 3ddata, data and res folders
    into your ROSE Online folder, letting them merge. Restart fully --
    documents and stylesheets only load at startup.

Each pack's own README is in the readmes folder.

UNINSTALL
    Every file this bundle installs is listed in .pack\FILE_LIST.txt, inside
    the bundle itself. Delete those files, or let a mod manager read that
    list and do it for you. ROSE prefers loose files to its packed
    archives, so nothing original is ever modified.
