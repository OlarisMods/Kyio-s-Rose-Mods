VOID HALLOWEEN -- Damage Up — Well of Souls
===========================================

A well below your feet, souls rising, lending you their strength.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
