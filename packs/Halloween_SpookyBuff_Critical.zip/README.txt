VOID HALLOWEEN -- Critical Up — Halloween Aura
==============================================

A spinning radiance of purple light with orange wisps rising within.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
