VOID HALLOWEEN -- HAUNTED SUMMONS
=================================
Every summon of every class becomes haunted: an aurora of spirit light
around it, and three wisps circling.

The effect is played by EVERY summon -- elementals, dragons, knights,
archers, the bird, the wolf, the bonfire -- so nothing in it covers the
creature. It only adds light.

WHAT IT IS
    Two aurora curtains encircle the summon, turning slowly in opposite
    directions. Where their rays line up the light swells; as they drift
    apart it dims. That is the pulse.

    Three wisps -- amber, violet and marsh green -- each on its own orbit,
    height and speed, bobbing as they go.

    All of it is meshes, not particles, so it is always there rather than
    being born and dying, and it reads the same from every angle.

FILES INCLUDED
    3ddata\EFFECT\mon_summons_01.eft

    3ddata\EFFECT\EFFECTMESH\_void_haunt_aurora_a.zms
    3ddata\EFFECT\EFFECTMESH\_void_haunt_aurora_a.zmo
    3ddata\EFFECT\EFFECTMESH\_void_haunt_aurora_b.zms
    3ddata\EFFECT\EFFECTMESH\_void_haunt_aurora_b.zmo
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_1.zms
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_1.zmo
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_2.zms
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_2.zmo
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_3.zms
    3ddata\EFFECT\EFFECTMESH\_void_haunt_wisp_3.zmo

    3ddata\EFFECT\Particles\Texture\_void_haunt_aurora.dds
    3ddata\EFFECT\Particles\Texture\_void_haunt_wisp.dds

INSTALL
    Copy the 3ddata folder into your ROSE Online install, keeping the
    folder structure exactly as it is. Nothing in the client is modified;
    delete these files to put your summons back to stock.


UNINSTALL
    Every file this pack installs is listed in .pack\filelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
