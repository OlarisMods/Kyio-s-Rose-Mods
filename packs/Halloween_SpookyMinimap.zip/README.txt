UPDATED FOR THE 16 OCTOBER 2026 PATCH  (version 1.1.0)
=====================================================
Rebuilt on the patched interface: the new chat settings button, party and
group controls, the HUD status icons and the data-driven minimap all work,
and every Spooky colour and addition is kept.

The headstone's sprites moved to spritesheet_spooky.css, and the buttons
keep their places around the stone.

UPGRADING FROM 1.0  -- one file to delete
    Delete this file from your ROSE Online folder if it is there:

        data\ui\themes\rose\styles\spritesheet_glassui.css

    Version 1.0 shipped its own copy of that sheet. A copy in your folder
    overrides the game's, so the patch's new buttons would draw blank.
    Spooky's sprites now live in their own file, spritesheet_spooky.css,
    and the game's sheet is left alone.

-----------------------------------------------------

====================================================================
  VOID HALLOWEEN -- TOMBSTONE MINIMAP
====================================================================

WHAT THIS IS
A weathered headstone around the minimap, with RIP cut into the
crown, moss creeping up from the foot, and a backlight that matches
the glow on the rest of the UI.

The map itself is arch-shaped. It is still a rectangle underneath --
the stone is drawn OVER it and crops it to the arch.

SOMETHING LIVES ON THE STONE
Keep half an eye on it while you play. It is there under 7% of the
time, so it rewards patience.

--------------------------------------------------------------------
WHAT IT CHANGES
--------------------------------------------------------------------
    3ddata\control\Res\glassui_03.dds
        the frame sprite, plus four small ones

    data\ui\themes\rose\styles\spritesheet_spooky.css
        the frame and the four small sprites, in their own sheet

    data\ui\themes\rose\game\minimap.html
        the frame's size and position, the map window, the zone-name
        tab, and the keyframes

--------------------------------------------------------------------
HOW TO INSTALL
--------------------------------------------------------------------
1. Close ROSE completely.
2. Copy '3ddata' and 'data' into your ROSE Online install folder,
   letting them merge.   Typical: C:\Program Files\ROSE Online
3. Start the game.

Textures re-read as you play, but the document and the spritesheet
are only read at startup -- so a full restart is needed, not a
character reload.

--------------------------------------------------------------------
HOW TO UNINSTALL
--------------------------------------------------------------------
UNINSTALL
    Every file this pack installs is listed in .packilelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.

--------------------------------------------------------------------
IF YOU WANT TO CHANGE IT
--------------------------------------------------------------------
build_tombstone_frame.py draws the stone. The shape, the moss, the
lip and the glow are all constants at the top.

The second build script draws what lives on the stone. The timings
are in minimap.html, in the @keyframes blocks -- change the seconds on
the 'animation:' lines to make them rarer or more frequent.


UNINSTALL
    Every file this pack installs is listed in .pack\FILE_LIST.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
