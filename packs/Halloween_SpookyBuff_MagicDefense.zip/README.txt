VOID HALLOWEEN -- Magic Defence Up — Soul Lantern
=================================================

A lantern holding your soul's flame, warding away unwanted magics.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
