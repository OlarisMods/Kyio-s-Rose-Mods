VOID HALLOWEEN -- Dodge Up — Ghostly After-Images
=================================================

Curious ghostly beings haunt your wake, making you harder to hit.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
