VOID HALLOWEEN -- Defence Up — Magic Sigil
==========================================

An esoteric circle, meant to dampen the blows of oncoming attacks.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
