VOID HALLOWEEN -- Move Speed Up — Summon Familiar
=================================================

A protective feline friend at your side, quickening your step and watching your back.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
