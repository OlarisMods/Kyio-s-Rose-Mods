VOID HALLOWEEN COMBAT TEXT
==========================
Damage numbers, status words and the crit effect, for ROSE Online.
Built 19 September 2026.

INSTALLING
    Copy the 3ddata folder into your ROSE Online install directory, keeping
    the structure exactly as it is here. Nothing in the client is modified;
    delete the files to remove it.

WHAT IS IN IT

    EFFECT\Special\                    the damage numbers and status words
        DIGITNUMBER01..06              six colours of 0-9
        DIGITNUMBERABSORB01            ABSORB, with a target badge
        DIGITNUMBERBLOCK01, 02         BLOCK!, violet and orange
        DIGITNUMBEREVADE01             EVADE!, with chevrons
        DIGITNUMBERIMMUNE01            IMMUNE!, with a star
        DIGITNUMBERMISS                MISS!, with the font's own X

    EFFECT\Particles\Texture\
        Critical.DDS                   CRIT!
        _void_mute_01, _sleep_01,      MUTE! SLEEP! STUN!
            _stun_01
        _void_bat_flock.dds            the bats, nine frames of a wing beat

    EFFECT\Particles\
        _CRITICAL_01.PTL               melee crits
        c_hit_01.ptl                   ranged, magical, and crits you TAKE
        _void_stun_01.ptl,             the particles that draw STUN! MUTE!
            _mute_01, _sleep_01            and SLEEP!

    EFFECT\
        _FAINTING_01.EFT               what the game plays on a STUN
        _MUTE_01.EFT                   ... on a MUTE
        _SLEEP_01.EFT                  ... on a SLEEP

EACH STATUS WORD IS A CHAIN OF THREE FILES
    _SLEEP_01.EFT  ->  _void_sleep_01.ptl  ->  _void_sleep_01.dds

    The game plays the wrapper, the wrapper plays the particle, the particle
    draws the word. All three must be installed. An earlier build of this pack
    shipped only the words and left the other two links out, so on a clean
    install the game played its own stun, mute and sleep instead.

TWO MASK ORDERS, AND THEY ARE NOT THE SAME
    EFFECT\Special         uncompressed 32-bit BGRA   Rmask 00ff0000
    EFFECT\Particles       uncompressed 32-bit RGBA   Rmask 000000ff

    Same pack, two subsystems, two conventions. Swapping them turns gold blue
    and nothing warns you. If you ever re-export these by hand, check this
    first.

    NONE of it is DXT1. That format carries one bit of alpha and two colours
    per 4x4 block, which on a two-colour design with an outline produced two
    hundred and thirty-five colours of mush. Everything here is uncompressed.

THE TEXT
    October Crow, rendered at 8x and downsampled, so the antialiasing comes
    from the real outline rather than from a mask. Three layers: a black
    letterform, a bright halo hugging it, and a wide soft pool of the same
    colour darkened behind that -- which is what stops it getting lost on a
    busy background.

THE CRIT
    Eight bats, released from a knot and lifting away over five seconds.
    Before: four emitters, counts of 12/12/8/10, each looping four times --
    168 sprites per crit, scattered across 240 units at birth so there was
    nothing to watch being released.

    They move slowly ON PURPOSE. The thing that makes a small dark shape read
    as a bat is having time to resolve it; anything quicker is just streaks.

BUILDING FROM SOURCE
    build_combat_text.py     the twelve Special sheets
    build_status_text.py     CRIT! MUTE! SLEEP! STUN!
    build_bat_flock.py       the wing-beat sheet
    build_crit_flock.py      rewrites the two crit PTLs
    rescue_digits.py         pulls DXT1 sheets back to clean two-colour BGRA

    Sizes, colours, halo widths and timings are all constants at the top of
    each file.


UNINSTALL
    Every file this pack installs is listed in .pack\filelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
