====================================================================
  REGAL BUFFS -- Durability Assist
  defence up  --  Soldier
====================================================================

A ward circle of runes -- love, light, luck, protection and growth.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 2 file(s):

    3ddata\Effect\EffectMesh\defend_01\greenglow1.dds
    3ddata\Effect\EffectMesh\defend_01\redglow1.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
WORTH KNOWING
--------------------------------------------------------------------
This buff is drawn by an effect MESH rather than a particle file,
so it is textures only. There is no .ptl to replace.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
