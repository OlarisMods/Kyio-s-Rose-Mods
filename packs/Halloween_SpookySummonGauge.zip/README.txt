UPDATED FOR THE 16 OCTOBER 2026 PATCH  (version 1.1.0)
=====================================================
Rebuilt on the patched interface: the new chat settings button, party and
group controls, the HUD status icons and the data-driven minimap all work,
and every Spooky colour and addition is kept.

UPGRADING FROM 1.0  -- one file to delete
    Delete this file from your ROSE Online folder if it is there:

        data\ui\themes\rose\styles\spritesheet_glassui.css

    Version 1.0 shipped its own copy of that sheet. A copy in your folder
    overrides the game's, so the patch's new buttons would draw blank.
    Spooky's sprites now live in their own file, spritesheet_spooky.css,
    and the game's sheet is left alone.

-----------------------------------------------------

VOID HALLOWEEN -- SUMMON GAUGE
==============================
A reworked summon bar. Neutral enough to sit in any theme.

WHAT IT ADDS
    readable at rest     rows at full opacity on a backdrop -- they used to
                         sit at 60% with nothing behind them until hovered
    low HP pulses        under 30% a row throbs red, so a dying summon is
                         noticed before it is gone
    out of range         the HP bar used to vanish silently when a summon was
                         far away; now a label says why
    capacity free        "5 free" under the bar, red when full
    HP as a number       beside each summon's name
    a ghost glow         three fading borders, matching the rest of the UI

Despawn buttons stay hover-only on purpose: an always-visible X beside every
summon is an easy misclick in a fight.

INSTALL
    Copy 'data' into your ROSE Online folder.

    The file is summon_gauge.html, with UNDERSCORES. The client loads that
    name; a copy named with hyphens is silently ignored.

    Documents are only read at startup, so restart the client fully.

UNINSTALL
    Every file this pack installs is listed in .packilelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.


UNINSTALL
    Every file this pack installs is listed in .pack\FILE_LIST.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
