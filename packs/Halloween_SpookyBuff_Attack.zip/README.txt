VOID HALLOWEEN -- Attack Power Up — Spooky Skull
================================================

A skull appears, oddly emboldening, bolstering your attack power.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
