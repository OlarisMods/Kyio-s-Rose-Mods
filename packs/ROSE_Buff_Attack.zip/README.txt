====================================================================
  REGAL BUFFS -- Power Overflow
  attack power up  --  Soldier
====================================================================

Two cutlasses crossed above you, flaring where they meet.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 2 file(s):

    3ddata\EFFECT\Particles\attackup_01.ptl
    3ddata\EFFECT\Particles\Texture\parry9.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
