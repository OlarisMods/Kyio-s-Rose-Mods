VOID HALLOWEEN -- Accuracy Up — Bat Familiar
============================================

A bat familiar echo-locating your enemies for you.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
