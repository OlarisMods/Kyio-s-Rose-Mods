====================================================================
  REGAL BUFFS -- Rapid Twitch
  move speed up  --  Hawker
====================================================================

Violet smoke at the feet, amber arcs, and a trail.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 7 file(s):

    3ddata\EFFECT\Particles\smoke_07.ptl
    3ddata\EFFECT\Particles\Texture\arcs9.dds
    3ddata\EFFECT\Particles\Texture\body9_deep.dds
    3ddata\EFFECT\Particles\Texture\body9_royal.dds
    3ddata\EFFECT\Particles\Texture\edge9.dds
    3ddata\EFFECT\Particles\Texture\smk_trail.dds
    3ddata\EFFECT\Particles\Texture\wisp_amber.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
