====================================================================
  REGAL BUFFS -- Critical Chant
  critical rate up  --  Dealer
====================================================================

Auroras turning behind the blades.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 4 file(s):

    3ddata\EFFECT\Particles\criticalup_01.ptl
    3ddata\EFFECT\Particles\Texture\rad9_amber.dds
    3ddata\EFFECT\Particles\Texture\rad9_violet.dds
    3ddata\EFFECT\Particles\Texture\spark_gold.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
