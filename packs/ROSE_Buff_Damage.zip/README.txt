====================================================================
  REGAL BUFFS -- Valkyrie Charm
  damage up  --  Muse
====================================================================

A veil of light at body height, with slow sparks.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 5 file(s):

    3ddata\EFFECT\Particles\damage_up01.ptl
    3ddata\EFFECT\Particles\Texture\cveil_amber.dds
    3ddata\EFFECT\Particles\Texture\cveil_violet.dds
    3ddata\EFFECT\Particles\Texture\spark_gold.dds
    3ddata\EFFECT\Particles\Texture\spark_lilac.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
