VOID HALLOWEEN -- STATE ICONS
=============================
Buff and debuff icons, quest markers, NPC map pins.

CLASS COLOURS -- each class its own colour, on the symbol AND the frame:
    blood  (214, 38, 34)
    marsh  (108, 232, 96)
    violet (150, 60, 240)
    amber  (255, 150, 40)

GLOW MINT (178, 255, 190) -- everything OUTSIDE the class system:
    the premium crown and no-XP
    recovery over time -- the game uses one icon for every kind, whatever
        its source: a class skill, a potion, a holiday item, a summon
    every other buff, marker and map pin

There are a treat or two hiding in there for the season. You will find
them.

Everything sits at 84% opacity. It is the ghost-themed UI, so the icons are
slightly insubstantial without becoming hard to find on a map.

INSTALL
    Copy 3ddata AND res into your ROSE Online folder. Both copies are shipped
    because the client reads the file from one or the other depending on
    context, and they must match. If a change does not show straight away,
    restart the client.

UNINSTALL
    Every file this pack installs is listed in .packilelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.


UNINSTALL
    Every file this pack installs is listed in .pack\filelist.txt, inside the
    pack itself. Delete those files, or let a mod manager read that list and
    do it for you. ROSE prefers loose files to its packed archives, so nothing
    original is ever modified.
