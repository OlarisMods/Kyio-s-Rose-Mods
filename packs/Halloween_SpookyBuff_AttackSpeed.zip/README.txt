VOID HALLOWEEN -- Attack Speed Up — Will-o-Wisps
================================================

Haunting wisps dance around you, strangely energizing.

INSTALL
    Copy the folders from this zip into your ROSE Online folder.
    Every file it installs is listed in .pack\FILE_LIST.txt.

UNINSTALL
    Delete those files.
