====================================================================
  REGAL BUFF ICONS
  sixteen buff icons, class coloured
====================================================================

Soldier red, Hawker green, Dealer yellow, Muse blue.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete this one file:

    3ddata\control\Res\stateicon.dds

--------------------------------------------------------------------
READ THIS BEFORE INSTALLING ANOTHER ICON PACK
--------------------------------------------------------------------
Every buff icon lives in that single shared sheet -- and so do the
quest log icons and the minimap markers.

So two icon packs can never be combined. Whichever you install last
replaces the entire sheet, including the parts the other pack was
changing.

Slots that were not designed for are left as plain outlined stars
rather than empty plates, so they read as neutral markers instead of
buffs that are not there.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the file above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
