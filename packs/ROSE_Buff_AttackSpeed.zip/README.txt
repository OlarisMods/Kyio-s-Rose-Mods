====================================================================
  REGAL BUFFS -- Haste
  attack speed up  --  Hawker, Battle Support
====================================================================

Two plasma orbs circling the waist, spinning as they go.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 4 file(s):

    3ddata\Effect\Motion\rotate_01.ZMO
    3ddata\EFFECT\Particles\defendup_01.ptl
    3ddata\EFFECT\Particles\Texture\orb9_amber.dds
    3ddata\EFFECT\Particles\Texture\orb9_violet.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
WORTH KNOWING
--------------------------------------------------------------------
The file it replaces is called defendup_01.ptl. That is not a
mistake -- the attack speed buff really is drawn by a file named
defendup.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
