====================================================================
  REGAL BUFFS -- Enhanced Reflexes
  dodge up  --  Hawker
====================================================================

The game's own flares, retinted amber and violet.

--------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------
1. Close ROSE Online.
2. Copy the 3ddata folder into your ROSE Online folder and let
   it merge with the one already there.
3. Start the game.

Nothing is installed and nothing is changed in the game's own
archives. These are loose files, which ROSE loads in preference
to what is packed inside it.

--------------------------------------------------------------------
UNINSTALL
--------------------------------------------------------------------
Delete these 2 file(s):

    3ddata\EFFECT\Particles\Texture\star_01.dds
    3ddata\EFFECT\Particles\Texture\Star_01.dds

The same list is in FILE_LIST.txt.

--------------------------------------------------------------------
WORTH KNOWING
--------------------------------------------------------------------
Both spellings of the texture are included -- star_01.dds and
Star_01.dds. The game refers to it both ways.

--------------------------------------------------------------------
IF SOMETHING LOOKS WRONG
--------------------------------------------------------------------
Delete the files above and you are back to the original.

Questions, or want a colour changing -- ask. Happy to help.
